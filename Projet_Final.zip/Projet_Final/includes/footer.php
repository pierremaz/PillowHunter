<footer>
	<div class="jumbotron text-center" style="margin-bottom: 0;"> 

		<h6>Copyright &copy; Gabriel Contois &amp; Clément Desavis &amp; Antoine Fournet&amp; Charlotte Lavaux  &amp; Pierre Mazure &amp; Baptiste Vanbaelinghem  2020 </h6>
	
	</div>

</footer>