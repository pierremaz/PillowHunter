<?php 
	
	require_once('Projet_Final/includes/header.php'); 


?>

<!DOCTYPE html>
<html>
  <head>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/p5@1.0.0/lib/p5.min.js"></script>
    
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/p5@1.0.0/lib/addons/p5.sound.min.js"></script>
    <script type="text/javascript" src="Projet_Final/Java/cell.js"></script>
    <script type="text/javascript" src="Projet_Final/Java/sketch.js"></script>
    <script type="text/javascript" src="JProjet_Final/ava/compteur.js"></script>
  </head>
  <body>
      <div id="divChrono">00:00:00</div>
  </body>
</html>