<?php 

	require_once('Projet_Final/includes/header.php');

?>





<?php
	require_once('Projet_Final/includes/footer.php');
?>
