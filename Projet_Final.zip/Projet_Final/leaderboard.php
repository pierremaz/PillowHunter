<?php 
	
	require_once('Projet_Final/includes/header.php');

	require_once('Projet_Final/includes/footer.php'); 

?>